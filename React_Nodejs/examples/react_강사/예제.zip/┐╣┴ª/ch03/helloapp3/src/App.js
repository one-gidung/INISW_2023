import React, { Component } from 'react';

class App extends Component {

    createString(x,y) {
        return (
            <div className="card card-body bg-light mb-3">{x} + {y} = {x+y}</div>
        )
    }

    render() {
        let msg = "World";
        return (
            <div className="container">
                <h1>Hello {msg}</h1>
                <hr className="dash-style" />
                { this.createString(4,5) }
            </div>        
        );
    }
}

export default App;