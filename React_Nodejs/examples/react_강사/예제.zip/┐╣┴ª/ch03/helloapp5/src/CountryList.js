import React, { Component } from 'react';

class CountryList extends Component {
    render() {
        const list = this.props.countries;

        let countries = list.map((item, index) => {
           return (
                <li key={item.no} 
                    className={item.visited ? 'list-group-item active' : 'list-group-item' }>
                    {item.country}
                </li>
            )
        })
        return (
            <ul className="list-group">{countries}</ul>
        );
    }
}
export default CountryList;
