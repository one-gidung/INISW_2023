import React, { useEffect, useState } from 'react';

const Clock2 = () => {
    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
      console.log("### Clock component is mounted!!");
      let handle = setInterval(() => {
        setCurrentTime(new Date());
        console.log("### tick!");
      }, 1000);
  
      return () => {
        console.log("### Clock component will be unmounted!!");
        clearInterval(handle);
      };
    }, []);
  
    return (
        <div style={{ padding:'10px', border:'solid 1px gray' }}>
            <h2>{ currentTime.toLocaleTimeString() }</h2>           
        </div>
    );
};

export default Clock2;