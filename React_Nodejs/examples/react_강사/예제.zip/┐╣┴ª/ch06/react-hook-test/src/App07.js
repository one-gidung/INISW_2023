import React, { useReducer, useState } from "react";
import produce from "immer";

let ts = new Date().getTime();
const initialTodoList = [
  { id: ts + 1, todo: "운동" },
  { id: ts + 2, todo: "독서" },
  { id: ts + 3, todo: "음악감상" },
]

const reducer = (todoList, action) => {
  switch (action.type) {
    case "addTodo":
      return produce(todoList, (draft) => {
        draft.push({ id: new Date().getTime(),todo: action.payload.todo });
      });
    case "deleteTodo":
      let index = todoList.findIndex(item => item.id === action.payload.id);
      return produce(todoList, (draft) => {
        draft.splice(index, 1);
      });
    default:
      return todoList;
  }
};

const App = () => {
  const [todoList, dispatchTodoList] = useReducer(reducer, initialTodoList);
  const [todo, setTodo] = useState("");
  const addTodo = () => {
    dispatchTodoList({ type: "addTodo", payload: { todo: todo } });
    setTodo("");
  }
  const deleteTodo = (id) => {
    dispatchTodoList({ type: "deleteTodo", payload: { id:id  }})
  }

  return (
    <div style={{ padding:'20px' }}>
      <input type="text" onChange={e => setTodo(e.target.value)} value={todo} />
      <button onClick={addTodo}>할일 추가</button>
      <ul>
        {todoList.map(item => (
          <li key={item.id}>
            {item.todo} &nbsp;&nbsp;
            <button onClick={()=>deleteTodo(item.id)}>삭제</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
