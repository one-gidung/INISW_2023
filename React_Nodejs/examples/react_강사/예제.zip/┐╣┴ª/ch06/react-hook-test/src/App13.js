import React from "react";
import { useMousePosition } from "./hooks/useMousePosition";

//Custom Hook 적용후
const App = () => {
  const position = useMousePosition();

  return (
    <h2>
      커스텀 훅 적용 [ {position.x}, {position.y} ]
    </h2>
  );
};

export default App;
