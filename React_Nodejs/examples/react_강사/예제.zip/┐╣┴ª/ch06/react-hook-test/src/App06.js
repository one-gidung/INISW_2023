import React, { useState, useEffect } from "react";
import axios from "axios";

const App = () => {
  const [name, setName] = useState('');
  const [contacts, setContacts] = useState([]);

  useEffect(() => {
    setName('ja');    //초기값 설정 예)현재시간, 게시판이라면 1페이지
  }, []);

  const searchContacts = () => {
    const url = `https://contactsvc.herokuapp.com/contacts/search/${name}`;
    axios.get(url).then(response => {
      if (response.data.status && response.data.status === 'fail') {
        alert(`조회 실패 : ${response.data.message}`);
      } else {
        setContacts(response.data);
      }
    });
  };

  return (
    <div style={{ padding: '20px' }}>
      이름 : <input
        type="text"
        value={name}
        onChange={e => setName(e.target.value)}
        onKeyUp={e => { if (e.code === 'Enter') searchContacts() }} 
      /><hr />
      <table className="list">
        <thead>
          <tr>
            <th>이름</th>
            <th>모바일</th>
            <th>이메일</th>
          </tr>
        </thead>
        <tbody>
          {
            contacts.map(c => (
              <tr key={c.no}>
                <td>{c.name}</td>
                <td>{c.tel}</td>
                <td>{c.address}</td>
              </tr>
            ))
          }
        </tbody>
      </table>
    </div>
  );
}

export default App;
