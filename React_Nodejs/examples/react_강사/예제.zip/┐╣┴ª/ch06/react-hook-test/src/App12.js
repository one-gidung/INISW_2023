import React, { useState, useEffect } from "react";

const App = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e) => setPosition({ x: e.pageX, y: e.pageY });
    window.addEventListener("mousemove", onMove);
    return () => {
      window.removeEventListener("mousemove", onMove);
    };
  }, []);

  return (
    <h2>
      {position.x}:{position.y}
    </h2>
  );
};
export default App;
