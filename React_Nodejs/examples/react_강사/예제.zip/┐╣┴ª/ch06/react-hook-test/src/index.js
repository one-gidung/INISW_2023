import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import App from './App';
import reportWebVitals from './reportWebVitals';

//import App from "./App01";
//import App from "./App02";
//import App from "./App03";
//import App from "./App04";
//import App from "./App05";
//import App from "./App06";
//import App from "./App07";
//import App from "./App08";
//import App from "./App09";
//import App from "./App10-before";
//import App from "./App10";
//import App from "./App11-before";
//import App from "./App11";
//import App from "./App11-nodep";
//import App from "./App12";
import App from "./App13";

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
