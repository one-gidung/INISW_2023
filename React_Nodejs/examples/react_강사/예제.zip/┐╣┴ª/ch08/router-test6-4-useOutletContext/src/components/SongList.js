import React from 'react'
import { Link, Outlet, useMatch } from 'react-router-dom';

const SongList = ({songs}) => {
    const pathMatch = useMatch('/songs/:id');
    let param_id = pathMatch ? parseInt(pathMatch.params.id,10) : -1 ;
    let list = songs.map((song)=> {
        let cn = "list-group-item";
        cn += param_id === song.id ? " list-group-item-secondary" : ""
        return (
            <li className={cn} key={song.id}>
                <Link to={`/songs/${song.id}`}>
                    {song.title} (musician: {song.musician})
                    <span className="float-right badge badge-secondary">
                        <i className="fa fa-play"></i>
                    </span>
                </Link>
            </li>
        )
    });

    return (
        <div>
            <h2 className="m-5">Song List</h2>
            <ul className="list-group">
                {list}
            </ul>
            <Outlet context={{songs}}/>
        </div>
    )
}
    
export default SongList;