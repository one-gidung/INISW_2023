import React, { useContext } from "react";
import { Navigate, useLocation } from "react-router";

//사용자 리스트 : 실제는 백엔드를 통해서 JWT와 같은 토큰을 받아오도록 작성
const staticUsers = [
    { userid:"user1", password:"1234", roles: [ "users" ] },
    { userid:"user2", password:"1234", roles: [ "users" ] },
    { userid:"admin", password:"1234", roles: [ "admins", "users" ] },
];
//경로에 접근할 때 필요한 Role 정보
const pathToRoles = [
    { path: "/users", role: "users" },
    { path: "/admins", role: "admins" },
];

let AuthContext = React.createContext();

const AuthProvider= ({ children }) => {
    let [userInfo, setUserInfo] = React.useState(null);
  
    const login = (userid, password, callback) =>{
        const user = staticUsers.find((u)=>u.userid === userid && u.password === password);
        if (user) {
            setUserInfo({ userid:user.userid, roles:user.roles });
            callback();
        } else {
            alert('로그인 실패!!');
        }
    }
    const logout = (callback) => {
        setUserInfo(null);
        callback();
    }
    const currentUserInfo = () => userInfo
    const isMatchToRoles = (path) => {
        let pathToRole = pathToRoles.find((p)=> p.path === path)
        if (!pathToRole) return false;
        
        if (!userInfo) return false;
        let index = userInfo.roles.findIndex((r)=> pathToRole.role===r);
        return index >= 0 ? true : false;
    }
  
    let value = { currentUserInfo, isMatchToRoles, login, logout };
  
    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

const useAuth = () => {
    return useContext(AuthContext);
}

const RequireAuth = ({ children }) => {
    let auth = useAuth();
    let location = useLocation();

    if (!auth.isMatchToRoles(location.pathname)) {
      return <Navigate to="/login" state={{ from: location }} replace />;
    }  
    return children;
}

export { useAuth, AuthProvider, RequireAuth };