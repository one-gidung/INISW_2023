import React from 'react';
import { useAuth } from '../AuthProvider';

const AdminPage = () => {
    const auth = useAuth();
    const userInfo = auth.currentUserInfo();
    return (
        <div>
            <h3>관리자 페이지 : admins 역할이 있어야 함.</h3>
            <p>userid : {userInfo.userid}</p>
            <p>roles : {userInfo.roles.join(',')}</p>
        </div>
    );
};

export default AdminPage;
