import React from 'react';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import { AuthProvider, RequireAuth } from './AuthProvider';
import AdminPage from './components/AdminPage';
import AuthButton from './components/AuthButton';
import LoginPage from './components/Login';
import PublicPage from './components/PublicPage';
import UserPage from './components/UserPage';

const App = () => {
    return (
      <AuthProvider>
        <Router>
        <div style={{ margin:'10px' }}>
            <ul>
                <li><Link to="/">홈</Link></li>
                <li><Link to="/users">사용자페이지</Link></li>
                <li><Link to="/admins">관리자페이지</Link></li>
            </ul>
            <AuthButton />
            <Routes>
                <Route path="/" element={<PublicPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/users" element={
                  <RequireAuth><UserPage /></RequireAuth>
                } />
                <Route path="/admins" element={
                  <RequireAuth><AdminPage /></RequireAuth>
                } />
            </Routes>
        </div>
        </Router>
      </AuthProvider>
    );
};

export default App;
