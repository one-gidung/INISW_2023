import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthProvider';


const AuthButton = () => {
    let navigate = useNavigate();
    const auth = useAuth();

    return auth.currentUserInfo() ? (
      <p>
        로그인 중 : (역할: {auth.currentUserInfo().roles.join(',')})
        <button onClick={() => { auth.logout(() => navigate("/"));  }} >logout </button>
      </p>
    ) : (
      <p>로그인하지 않았음.</p>
    );
};

export default AuthButton;
