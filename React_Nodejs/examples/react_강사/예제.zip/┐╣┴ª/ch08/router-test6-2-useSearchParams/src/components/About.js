import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';

const About = ({title}) => {
    let [searchParams, setSearchParams] = useSearchParams();
    let [page, setPage] = useState(0);

    useEffect(()=>{
        let currentPage = parseInt(searchParams.get('page'), 10);
        currentPage = isNaN(currentPage) ? 1 : currentPage;
        setPage(currentPage);
    }, [searchParams])

    const goNext = () => {
        setSearchParams({ page:page+1 });
    }
    const goPrev = () => {
        if (page > 1) setSearchParams({ page:page-1 });
    }
    return (
        <div className="card card-body">
            <h2>About {title} </h2>
            <div>
                <div>Page : {page}</div>
                <button onClick={goPrev}>Prev</button><button onClick={goNext}>Next</button>
            </div>
        </div>
    );
};

export default About;