import React from 'react';
import { useLocation } from 'react-router';

const Home = () => {
    const location = useLocation();
    const from = location.state && location.state.from ? location.state.from : "";
    return (
        <div className="card card-body">
            <h2>Home</h2>
            {from !== "" ? <h4>from : {from}</h4> : "" }
        </div>
    );
};

export default Home;