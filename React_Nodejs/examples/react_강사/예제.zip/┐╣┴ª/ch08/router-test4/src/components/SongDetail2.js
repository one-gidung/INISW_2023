import React, { Component } from 'react';
import { Link, useParams } from 'react-router-dom';

const withParams = (Component) => {
    return (props) => <Component {...props} params={useParams()} />;
}

class SongDetail2 extends Component {
    render() {
        const id = parseInt(this.props.params.id, 10);
        const song = this.props.songs.find((song)=> song.id === id);
        const full_link = `https://m.youtube.com/watch?v=${song.youtube_link}`;
    
        return (
            <div className="mt-5">
                <h2>{song.title}</h2>
                <p>Original Musician : {song.musician}</p>
                <p><a href={full_link} target="new">View Youtube</a></p>
                <Link to="/songs">Return SongList</Link>
            </div>
        );
    }
}

export default withParams(SongDetail2);