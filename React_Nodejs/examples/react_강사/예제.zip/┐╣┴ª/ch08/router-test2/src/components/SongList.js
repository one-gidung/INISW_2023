import React from 'react';

const SongList = () => {
    return (
        <div className="card card-body">
            <h2>SongList</h2>
        </div>
    );
};

export default SongList;