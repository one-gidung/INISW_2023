import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Header from './Header';
import Home from './Home';
import About from './About';
import SongList from './SongList';
import Members from './Members';

const App = () => {
    return (
        <Router>
            <div className="container">
                <Header />
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/members" element={<Members />} />
                    <Route path="/songs" element={<SongList />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;