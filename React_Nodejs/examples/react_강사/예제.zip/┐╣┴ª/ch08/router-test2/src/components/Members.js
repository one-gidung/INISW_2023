import React from 'react';

const Members = () => {
    return (
        <div className="card card-body">
            <h2>Members</h2>
        </div>
    );
};

export default Members;