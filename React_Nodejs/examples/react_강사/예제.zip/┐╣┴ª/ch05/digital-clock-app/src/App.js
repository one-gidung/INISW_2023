import React, { Component } from 'react';
import Clock from './Clock';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = { isVisible : false };
    }
    
    toggleVisible = () => {
        this.setState({ isVisible : !this.state.isVisible });
    }

    render() {
        return (
            <div style={{ padding: '10px' }}>
                <button onClick={this.toggleVisible}>Toggle!!</button>
                { this.state.isVisible ? <Clock /> : "" }
            </div>
        );
    }
}

export default App;