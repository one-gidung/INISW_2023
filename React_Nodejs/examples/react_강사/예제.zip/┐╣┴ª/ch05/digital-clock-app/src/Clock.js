import React, { Component } from 'react';

class Clock extends Component {
    constructor(props) {
        super(props);
        this.state = { currentTime : new Date() }
    }

    componentDidMount() {
        this.handle = window.setInterval(() => {
            console.log("### tick!");
            this.setState({ currentTime : new Date() });
        }, 1000);
    }
    
    componentWillUnmount() {
        window.clearInterval(this.handle);
    }
    
    render() {
        return (
            <div style={{ padding:'10px', border:'solid 1px gray' }}>
                <h2>{ this.state.currentTime.toLocaleTimeString() }</h2>           
            </div>
        );
    }
}

export default Clock;