import React, { Component } from 'react';
import styled from 'styled-components'

class Footer extends Component {
    render() {
        const FooterBox = styled.div`
            position: absolute;
            right: 0; bottom: 0;  left: 0;
            padding: 1rem;
            background-color: ${ 
                (props)=> props.theme === 'basic' ? 'skyblue' : 'yellow'
            };
            text-align: center;
        `;
        return (
            <FooterBox theme={this.props.theme}>React styled-component Test!!</FooterBox>
        );
    }
}
export default Footer;
