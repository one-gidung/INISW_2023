import React, { Component } from 'react';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = { num:0 };
    }
    add = ()=> { this.setState({ num: this.state.num+1 });  }
    subtract = ()=> { this.setState({ num : this.state.num-1 }); }
    render() {
        return (
            <div className="container">
                <button onClick={this.add}> + </button>
                <button onClick={this.subtract}> - </button>
                <hr />
                <input type="text" value={this.state.num} />
            </div>
        );
    }
}

export default App;