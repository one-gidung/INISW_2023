import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Calc from './Calc';
import reportWebVitals from './reportWebVitals';

//let values = { x:'aaa', y:'bbb', oper:"/" };

// ReactDOM.render(
//   <React.StrictMode>
//     <Calc {...values} />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

ReactDOM.render(
  <React.StrictMode>
    <Calc />
  </React.StrictMode>,
  document.getElementById('root')
);


// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
